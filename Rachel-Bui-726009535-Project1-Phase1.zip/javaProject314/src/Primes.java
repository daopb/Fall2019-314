import java.util.ArrayList;
import java.math.BigInteger;

/*
 *  Desc: This class generates primes, twin primes, and hexagon crosses using BigInteger data types.
 */
public class Primes {
	
	// Pair class implementation.
	private class Pair<T> {
		private T first, second;	//data members of pair class
		private Pair(T first, T second)	//constructor, create a pair of 2 primes
		{
			this.first = first;
			this.second = second;
		}
		private T getLeft()		//get the value of first prime
		{
			return first;
		}
		private T getRight()	//get the value of second prime
		{
			return second;
		}
		
	}

	// Member variables for containing out lists of integers, twin primes, hexagon crosses, and the pairs of twin primes that make up the hex crosses.
	private ArrayList<BigInteger> primeList = new ArrayList<BigInteger>();	//create a list containing primes
	private ArrayList<Pair<BigInteger>> twinPrimesList = new ArrayList<Pair<BigInteger>>();	//create a list of pairs of twin primes
	private ArrayList<BigInteger> midPointOfTwinPrimes = new ArrayList<BigInteger>();	//create a list of twin primes' middle point	
	private ArrayList<Pair<Integer>> indexHexCrosses = new ArrayList<Pair<Integer>>();	//a list containing indexes of two twin primes and their midpoint that make up the hex crosses
	
	// Add a prime to the prime list if and only iff it is not already in the list. (ignore duplicates)
	public void addPrime(BigInteger x)
	{
		int numOfPrimes = primeList.size();		//get number of primes in prime list
		boolean duplicate = false;		//initialize duplicate to be false
		for(int i = 0; i<numOfPrimes; i++)
		{
			if(primeList.get(i).equals(x))		//if prime x is in the list, duplicate = true
			{
				duplicate = true;
			}
		}
		if(!duplicate)		//if x is not in prime list, then add x into the prime list
		{		
			primeList.add(x);
		}
	}
	
	// Output the prime list. Each prime should be on a separate line and the total number of primes should be on the following line.
	public void printPrimes()
	{
		int numOfPrimes = primeList.size();		//get number of primes in prime list
		for(int i = 0; i<numOfPrimes; i++)		//display the list of primes
		{
			System.out.println(primeList.get(i).toString());
		}
		System.out.println("Total Primes: " + numOfPrimes);		//display total number of primes
	}
		
	// Output the twin prime list. Each twin prime should be on a separate line with a comma separating them, and the total number of twin primes should be on the following line.
	public void printTwins()
	{
		int numOfTwin = twinPrimesList.size();	//get number of twin primes
		for(int i = 0; i<numOfTwin; i++)	//display the list of twin primes
		{
			System.out.println(twinPrimesList.get(i).getLeft().toString()+ ", " + twinPrimesList.get(i).getRight().toString());
		}
		System.out.println("Total Twins: " + numOfTwin);	//display total number of twin primes
	}
		
	// Output the hexagon cross list. Each should be on a separate line listing the two twin primes and the corresponding hexagon cross, with the total number on the following line.
	public void printHexes()
	{
		int numOfHexes = indexHexCrosses.size();	//get number of hexes
		for(int i = 0; i < numOfHexes; i++) 		//display list of hex crosses and two twin primes that generate the hex crosses
		{
			//get a pair of indexes of two twin primes in twinPrimesList that generate the hex crosses
			//and they are also the pair of indexes of hex crosses in midPointOfTwinPrimes lists 
			Pair<Integer> indHex = indexHexCrosses.get(i);
			Pair<BigInteger> p1 = twinPrimesList.get(indHex.getLeft());		//twin primes associate with left index
			Pair<BigInteger> p2 = twinPrimesList.get(indHex.getRight());	//twin primes associate with right index
			System.out.print("Prime Pairs: ");		//display two twin primes along with hex crosses
			System.out.print("("+ p1.getLeft().toString()+ ", " + p1.getRight().toString()+ ")");
			System.out.print(" and ");
			System.out.print("("+ p2.getLeft().toString()+ ", " + p2.getRight().toString()+ ")");
			System.out.println(" separated by " + midPointOfTwinPrimes.get(indHex.getLeft()).toString() + ", " + midPointOfTwinPrimes.get(indHex.getRight()).toString());
		}
		System.out.println("Total Hexes: " + numOfHexes);		//display total number of hexes
	}
		
	// Generate and store a list of primes.
	public void generatePrimes(int count)
	{	
		if(count <= 0)
		{
			System.out.println("No primes are generated");
		}
		else if(count == 1) {
			primeList.add(BigInteger.ONE);	//1st prime = 1
		}
		else if(count == 2) {
			primeList.add(BigInteger.ONE);	//1st prime = 1
			primeList.add(BigInteger.TWO);	//2nd prime = 2
		}
		else if(count == 3)
		{
			primeList.add(BigInteger.ONE);	//1st prime = 1
			primeList.add(BigInteger.TWO);	//2nd prime = 2
			primeList.add(new BigInteger("3"));		//3rd prime = 3
		}
		else 
		{
			primeList.add(BigInteger.ONE);	//1st prime = 1
			primeList.add(BigInteger.TWO);	//2nd prime = 2
			primeList.add(new BigInteger("3"));		//3rd prime = 3
			BigInteger num = new BigInteger("4");		//starting from number 4 and check if it is prime
			int i = 3;						//count number of primes
			while(i<count)					//do while number of prime is less than count
			{
				boolean notPrime = false;		//not a prime
				BigInteger a = num.divide(BigInteger.TWO);		//a = num/2
				//if num is not divisible by any number between 2 and num/2 then num is a prime
				for(BigInteger j = BigInteger.TWO; j.compareTo(a) <= 0; j = j.add(BigInteger.ONE))
				{
					BigInteger remainder = num.mod(j);		//calculate remainder = num (mod j)
					if(remainder.compareTo(BigInteger.ZERO) == 0)	//if remainder == 0, then num is divisible by j, therefore num is not a prime
					{
						notPrime = true;	//set notPrime = true 
						break;				//exit the loop
					}
				}
				if(notPrime == false)		//if notPrime is false, then num is prime 
				{
					primeList.add(num);		//add num to the prime list
					i++;					//increment the number of primes
				}
				num = num.add(BigInteger.ONE);		//check next number
			}
		}
	}
	
	// Generate and store a list of twin primes.
	public void generateTwinPrimes()
	{
		int length = primeList.size();		//number of primes in the prime list
		for(int i = 0; i<(length-1); i++)
		{
			BigInteger Diff = primeList.get(i+1).subtract(primeList.get(i)); //calculate the difference between two primes
			//if the difference between 2 primes is 2, the they are twin primes
			if(Diff.equals(BigInteger.TWO))
			{
				twinPrimesList.add(new Pair<BigInteger>(primeList.get(i), primeList.get(i+1)));	//found twin primes, add them to twinPrimesList
			}
		}
	}
	
	// Generate and store the hexagon crosses, along with the two twin primes that generate the hexagon cross.
	public void generateHexPrimes()
	{
		int sizeOfTwinPrimeList = twinPrimesList.size();	//get size of twin prime list
		for(int i = 0; i < (sizeOfTwinPrimeList); i++)
		{
			Pair<BigInteger> temp = twinPrimesList.get(i);	//get twin primes
			//find the midpoint of twin primes and add it to midPointTwinPrimes list
			//midpoint = sum of twin primes divided by 2
			midPointOfTwinPrimes.add((temp.getRight().add(temp.getLeft())).divide(BigInteger.TWO));
		}
		//hexagon cross is a pair of numbers that are the middle integer between the primes in a twin prime,
		//such that the second number in the pair is twice the first number
		//get the indexes those twin primes from the twinPrimesList and add them to indexHexCrosses list as a pair
		for(int i = 0; i<(sizeOfTwinPrimeList-1); i++)
		{
			for(int j = i+1; j < sizeOfTwinPrimeList; j++)
			{
				BigInteger Div = midPointOfTwinPrimes.get(j).divide(midPointOfTwinPrimes.get(i));	//calculate a quotient of midpoints of twin primes at index j and i
				BigInteger Modo = midPointOfTwinPrimes.get(j).mod(midPointOfTwinPrimes.get(i));		//calculate a remainder of that quotient
				if((Div.equals(BigInteger.TWO))&&(Modo.equals(BigInteger.ZERO)))	//if the quotient == 2 and the remainder == 0, found hexagon cross
				{
					indexHexCrosses.add(new Pair<Integer>(i, j));	//add a pair of indexes of hex cross in twinPrimesList to indexHexCrosses list
					break;	//stop the loop when hex crosses is found
				}
			}	
		}
	}
}
